/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package attendancemanagementsystem;

import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Login extends javax.swing.JFrame {

    static User obj;
    static int count = 0;

    public Login() {
        initComponents();
        this.setLocationRelativeTo(null);
        if (count == 0) {
            University.dummyUsers();
            count++;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        username = new javax.swing.JTextField();
        login = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        newAccount = new javax.swing.JLabel();
        passwordForgot = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        username.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        username.setText("Email");
        username.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        username.setPreferredSize(new java.awt.Dimension(80, 40));
        username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameActionPerformed(evt);
            }
        });
        jPanel1.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 302, -1));

        login.setBackground(new java.awt.Color(9, 38, 53));
        login.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        login.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loginMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginMouseExited(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Log in");

        javax.swing.GroupLayout loginLayout = new javax.swing.GroupLayout(login);
        login.setLayout(loginLayout);
        loginLayout.setHorizontalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginLayout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addComponent(jLabel2)
                .addContainerGap(145, Short.MAX_VALUE))
        );
        loginLayout.setVerticalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel1.add(login, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 340, -1));

        password.setText("  password");
        password.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        jPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 335, 302, 40));

        newAccount.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        newAccount.setText("Create New Account");
        newAccount.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        newAccount.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                newAccountMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                newAccountMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                newAccountMouseExited(evt);
            }
        });
        jPanel1.add(newAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, -1, -1));

        passwordForgot.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        passwordForgot.setText("Forgot Password ?");
        passwordForgot.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        passwordForgot.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passwordForgotMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                passwordForgotMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                passwordForgotMouseExited(evt);
            }
        });
        jPanel1.add(passwordForgot, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 530, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 53, 69));
        jLabel4.setText("PARTICIPANTS");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(9, 38, 53));
        jLabel6.setText("LOGIN");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, -1, 40));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/user.png"))); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/padlock.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, -1, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 0, 380, 640));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255,220));
        jLabel3.setFont(new java.awt.Font("Felix Titling", 1, 48)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("ATTendance");
        jLabel3.setToolTipText("");
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel3.setPreferredSize(new java.awt.Dimension(30, 16));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 570, 49));

        jLabel5.setFont(new java.awt.Font("Felix Titling", 1, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("PORTAL");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 570, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/login.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void loginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginMouseClicked
        // TODO add your handling code here:

        String role = University.verifyUser(username.getText().trim(), new String(password.getPassword()).trim());
        if (role != null) {
            if (role.trim().equalsIgnoreCase("no role")) {
                obj = University.loginUser(username.getText().trim(), new String(password.getPassword()).trim());
                this.setVisible(false);
                this.dispose();
                new AdminDashboard().setVisible(true);
            } else if (role.trim().equalsIgnoreCase("Teacher")) {
                obj = University.loginUser(username.getText().trim(), new String(password.getPassword()).trim());
                this.setVisible(false);
                this.dispose();
                new Teacher_Portal().setVisible(true);
            } else if (role.trim().equalsIgnoreCase("Student")) {
                obj = University.loginUser(username.getText().trim(), new String(password.getPassword()).trim());
                this.setVisible(false);
                this.dispose();
                new StudentDashboard().setVisible(true);
            } else {
                University.dialogeMsg("Incorrect credential!");
            }
        }

    }//GEN-LAST:event_loginMouseClicked

    private void loginMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginMouseEntered
        // TODO add your handling code here:
        login.setBackground(new Color(0, 102, 204));
    }//GEN-LAST:event_loginMouseEntered

    private void loginMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginMouseExited
        // TODO add your handling code here:
        login.setBackground(new Color(9, 38, 53));

    }//GEN-LAST:event_loginMouseExited

    private void newAccountMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newAccountMouseEntered
        // TODO add your handling code here:
        newAccount.setForeground(new Color(0, 102, 204));
    }//GEN-LAST:event_newAccountMouseEntered

    private void passwordForgotMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passwordForgotMouseEntered
        // TODO add your handling code here:
        passwordForgot.setForeground(new Color(0, 102, 204));
    }//GEN-LAST:event_passwordForgotMouseEntered

    private void passwordForgotMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passwordForgotMouseExited
        // TODO add your handling code here:
        passwordForgot.setForeground(new Color(0, 0, 0));
    }//GEN-LAST:event_passwordForgotMouseExited

    private void newAccountMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newAccountMouseExited
        // TODO add your handling code here:
        newAccount.setForeground(new Color(0, 0, 0));
    }//GEN-LAST:event_newAccountMouseExited

    private void newAccountMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newAccountMouseClicked
        // TODO add your handling code here:
        this.setVisible(false);
        this.dispose();
        new SignUp().setVisible(true);
    }//GEN-LAST:event_newAccountMouseClicked

    private void passwordForgotMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passwordForgotMouseClicked
        // TODO add your handling code here:
        new Password().setVisible(true);
    }//GEN-LAST:event_passwordForgotMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel login;
    private javax.swing.JLabel newAccount;
    private javax.swing.JPasswordField password;
    private javax.swing.JLabel passwordForgot;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
