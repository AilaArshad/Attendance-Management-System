package attendancemanagementsystem;

public class User {

    private String name;
    private String email;
    private String password;
    private String security_q;
    private String security_a;
    private String role;
    private String ph_no;

    public User() {
    }

    public User(String name, String email, String password, String security_q, String security_a, String role, String ph_no) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.security_q = security_q;
        this.security_a = security_a;
        this.role = role;
        this.ph_no = ph_no;
    }

    public String getPh_no() {
        return ph_no;
    }

    public void setPh_no(String ph_no) {
        if (ph_no != null && !ph_no.trim().isEmpty() && ph_no.matches("^03\\d{9}$")) {
            this.ph_no = ph_no;
        } else {
            throw new IllegalArgumentException("Phone number must start with '03', consist of digits only, and be 11 characters long.");
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name cannot be empty or null.");
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email != null && !email.trim().isEmpty() && email.endsWith("@gmail.com")) {
            this.email = email;
        } else {
            throw new IllegalArgumentException("Email must end with '@gmail.com' and cannot be empty.");
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password != null && !password.trim().isEmpty()) {
            this.password = password;
        } else {
            throw new IllegalArgumentException("Password cannot be empty or null.");
        }
    }

    public String getSecurity_q() {
        return security_q;
    }

    public void setSecurity_q(String security_q) {
        this.security_q = security_q;
    }

    public String getSecurity_a() {
        return security_a;
    }

    public void setSecurity_a(String security_a) {
        if (security_a != null && !security_a.trim().isEmpty()) {
            this.security_a = security_a;
        } else {
            throw new IllegalArgumentException("Answer cannot be empty or null.");
        }
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isValid() {
        if (ph_no != null && !ph_no.trim().isEmpty() && ph_no.matches("^03\\d{9}$") && name != null && !name.trim().isEmpty()
                && email != null && !email.trim().isEmpty() && email.endsWith("@gmail.com") && password != null && !password.trim().isEmpty()
                && security_a != null && !security_a.trim().isEmpty()) {
            return true;
        }
        return false;
    }
}
