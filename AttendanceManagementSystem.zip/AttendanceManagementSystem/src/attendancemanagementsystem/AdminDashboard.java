/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package attendancemanagementsystem;

import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultCellEditor;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aila Arshad
 */
public class AdminDashboard extends javax.swing.JFrame {

    private DefaultTableModel model;
    private Timer t;
    private SimpleDateFormat sdf;

    public AdminDashboard() {
        initComponents();
        this.setLocationRelativeTo(null);
        date();
        time();
        showStudentList("Student", studentTable);
        showStudentList("Teacher", teacherTable);
        showCourseList(coursetable);
        studentCount.setText(University.getUserNum("Student") + "");
        TeacherCount.setText(University.getUserNum("Teacher") + "");
        courseCount.setText(University.courseNum() + "");
        for (String s : University.UserNameList("Teacher")) {
            if (s != null) {
                teacherName.addItem(s.trim());
                A_Teacher.addItem(s.trim());
                A_Teacher1.addItem(s.trim());
                advisorPortalSearch.addItem(s.trim());
            }
        }
        for (String s : University.UserNameList("Student")) {
            if (s != null) {
                studentName.addItem(s.trim());
            }
        }
        for (String s : University.CourseNameList()) {
            if (s != null) {
                course.addItem(s.trim());
                teacherCourse.addItem(s);

            }
        }
        defaultTextSetter();
        if (University.getEnrollment() != null) {
            showEnrolledList();
        }
        if (University.getWorkloadList() != null) {
            showWorkloadList();
        }
        if (Login.obj != null) {
            profileSetting(Login.obj);
        }
    }

    private void showStudentList(String role, JTable table) {
        model = (DefaultTableModel) table.getModel();
        ArrayList<User> list = University.getUser(role);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                Object[] col = new Object[6];
                col[0] = list.get(i).getName();
                col[1] = list.get(i).getEmail();
                col[2] = list.get(i).getPh_no();
                col[3] = list.get(i).getPassword();
                col[4] = list.get(i).getSecurity_q();
                col[5] = list.get(i).getSecurity_a();
                model.addRow(col);
            }
        }
    }

    void searchedStudents(ArrayList<User> list, JTable table) {
        model = (DefaultTableModel) table.getModel();
        if (list != null) {
            model.setRowCount(0);
            for (int i = 0; i < list.size(); i++) {
                Object[] col = new Object[6];
                col[0] = list.get(i).getName();
                col[1] = list.get(i).getEmail();
                col[2] = list.get(i).getPh_no();
                col[3] = list.get(i).getPassword();
                col[4] = list.get(i).getSecurity_q();
                col[5] = list.get(i).getSecurity_a();
                model.addRow(col);
            }
        }
    }

    private void showCourseList(JTable table) {
        model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        ArrayList<Course> list = University.getCourse();
        if (list != null) {
            for (Course course : list) {
                ArrayList<Section> sections = course.getSections();
                for (Section section : sections) {
                    Object[] col = new Object[5];
                    col[0] = course.getName();
                    col[1] = course.getC_code();
                    col[2] = section.getName();
                    col[3] = section.getClass_days();
                    col[4] = section.getClass_time_slot();
                    model.addRow(col);
                }
            }
        }
    }

    private void showEnrolledList() {
        model = (DefaultTableModel) studentEnrollmentTable.getModel();
        model.setRowCount(0);
        ArrayList<Enrollment> list = University.getEnrollment();
        if (list != null) {
            for (Enrollment enroll : list) {
                ArrayList<Section> sections = enroll.getCourse().getSections();
                for (Section section : sections) {
                    Object[] col = new Object[6];
                    col[0] = enroll.getStd().getName();
                    col[1] = enroll.getCourse().getName();
                    col[2] = enroll.getTea().getName();
                    col[3] = section.getName();
                    col[4] = section.getClass_days();
                    col[5] = section.getClass_time_slot();
                    model.addRow(col);
                }
            }
        }
    }

    private void showWorkloadList() {
        model = (DefaultTableModel) workLoadTable.getModel();
        model.setRowCount(0);
        ArrayList<WorkLoad> list = University.getWorkloadList();
        if (list != null) {
            for (WorkLoad work : list) {
                ArrayList<Section> sections = work.getCourse().getSections();
                for (Section section : sections) {
                    Object[] col = new Object[5];
                    col[0] = work.getTeacher().getName();
                    col[1] = work.getCourse().getName();
                    col[2] = section.getName();
                    col[3] = section.getClass_days();
                    col[4] = section.getClass_time_slot();
                    model.addRow(col);
                }
            }
        }
    }

    void searchedCourses(ArrayList<Course> list, JTable table) {
        model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        if (list != null) {
            for (Course course : list) {
                ArrayList<Section> sections = course.getSections();
                for (Section section : sections) {
                    Object[] col = new Object[5];
                    col[0] = course.getName();
                    col[1] = course.getC_code();
                    col[2] = section.getName();
                    col[3] = section.getClass_days();
                    col[4] = section.getClass_time_slot();
                    model.addRow(col);
                }
            }
        }
    }

    void defaultTextSetter() {
        adminName.setEditable(false);
        adminPass.setEditable(false);
        adminEmail.setEditable(false);
        adminAns.setEditable(false);
        adminPh.setEditable(false);
        A_Teacher.setEnabled(false);
        A_portalCourse.setEnabled(false);
        A_PortalSection.setEnabled(false);
    }

    void profileSetting(User obj) {
        adminName.setText(obj.getName());
        adminPass.setText(obj.getPassword());
        adminEmail.setText(obj.getEmail());
        adminQue.setSelectedItem(obj.getSecurity_q());
        adminAns.setText(obj.getSecurity_a());
        adminPh.setText(obj.getPh_no());
    }

    public void date() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM-dd");
        String dd = sdf.format(d);
        date.setText(dd);

    }

    public void time() {

        t = new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date dt = new Date();
                sdf = new SimpleDateFormat("hh:mm:ss a");
                String s = sdf.format(dt);
                time.setText(s);
            }
        });
        t.start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        status_combo = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Dashboard = new javax.swing.JPanel();
        c = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        courseCount = new javax.swing.JLabel();
        s = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        studentCount = new javax.swing.JLabel();
        p = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        TeacherCount = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        StudentPortal = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel13 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        studentSearch = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jLabel26 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        studentSection = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        studentName = new javax.swing.JComboBox<>();
        course = new javax.swing.JComboBox<>();
        teacher = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        studentEnrollmentTable = new javax.swing.JTable();
        jPanel15 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        UserPortal = new javax.swing.JPanel();
        userAns = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        UserName = new javax.swing.JTextField();
        userEmail = new javax.swing.JTextField();
        userNum = new javax.swing.JTextField();
        userQue = new javax.swing.JComboBox<>();
        userRole = new javax.swing.JComboBox<>();
        userPass = new javax.swing.JTextField();
        userRegister = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        A_Portal = new javax.swing.JPanel();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        A_PortalSection = new javax.swing.JComboBox<>();
        A_portalCourse = new javax.swing.JComboBox<>();
        jLabel70 = new javax.swing.JLabel();
        A_Teacher = new javax.swing.JComboBox<>();
        jLabel71 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        attendanceTable = new javax.swing.JTable();
        jPanel26 = new javax.swing.JPanel();
        jLabel78 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        A_PortalSection1 = new javax.swing.JComboBox<>();
        A_PortalCourse1 = new javax.swing.JComboBox<>();
        A_Teacher1 = new javax.swing.JComboBox<>();
        jScrollPane10 = new javax.swing.JScrollPane();
        allAttendanceTable = new javax.swing.JTable();
        jPanel25 = new javax.swing.JPanel();
        jLabel76 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        Setting = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        adminEmail = new javax.swing.JTextField();
        adminName = new javax.swing.JTextField();
        adminAns = new javax.swing.JTextField();
        adminPh = new javax.swing.JTextField();
        adminPass = new javax.swing.JTextField();
        adminQue = new javax.swing.JComboBox<>();
        jPanel20 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        TeacherPortal = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel16 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        searchTeacher = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        teacherTable = new javax.swing.JTable();
        jLabel36 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        teacherSection = new javax.swing.JComboBox<>();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        teacherName = new javax.swing.JComboBox<>();
        teacherCourse = new javax.swing.JComboBox<>();
        jLabel42 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        workLoadTable = new javax.swing.JTable();
        jLabel37 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        studentStatusTable = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        jLabel60 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        advisorPortalSearch = new javax.swing.JComboBox<>();
        jLabel58 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        CoursePortal = new javax.swing.JPanel();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        courseCode = new javax.swing.JTextField();
        courseName = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        CourseTable = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        jLabel66 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel67 = new javax.swing.JLabel();
        courseS = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        coursetable = new javax.swing.JTable();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        status_combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Approved", "Cancelled" }));
        status_combo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        status_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                status_comboActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(9, 38, 53));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/admin.png"))); // NOI18N
        jLabel1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ADMIN");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/home.png"))); // NOI18N
        jLabel3.setText(" Dashboard");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/portal.png"))); // NOI18N
        jLabel4.setText(" Course Portal");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/graduating-student.png"))); // NOI18N
        jLabel5.setText(" Student Portal");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/teacher.png"))); // NOI18N
        jLabel6.setText(" Teacher Portal");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/profile.png"))); // NOI18N
        jLabel7.setText(" User Portal");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/attendance.png"))); // NOI18N
        jLabel8.setText(" A-Portal");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/setting.png"))); // NOI18N
        jLabel9.setText(" Setting");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/logout.png"))); // NOI18N
        jLabel10.setText(" Log Out");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(90, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 280, 630));

        Dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        c.setBackground(new java.awt.Color(255, 255, 255, 80));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel13.setText("Courses");

        courseCount.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        courseCount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        courseCount.setText("0");

        javax.swing.GroupLayout cLayout = new javax.swing.GroupLayout(c);
        c.setLayout(cLayout);
        cLayout.setHorizontalGroup(
            cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cLayout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(courseCount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        cLayout.setVerticalGroup(
            cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel13)
                .addGap(30, 30, 30)
                .addComponent(courseCount, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        Dashboard.add(c, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 60, 330, 190));

        s.setBackground(new java.awt.Color(255, 255, 255, 80));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Students");

        studentCount.setBackground(new java.awt.Color(0, 204, 204));
        studentCount.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        studentCount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        studentCount.setText("0");

        javax.swing.GroupLayout sLayout = new javax.swing.GroupLayout(s);
        s.setLayout(sLayout);
        sLayout.setHorizontalGroup(
            sLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(studentCount, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        sLayout.setVerticalGroup(
            sLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel11)
                .addGap(32, 32, 32)
                .addComponent(studentCount, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        Dashboard.add(s, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 330, 190));

        p.setBackground(new java.awt.Color(255, 255, 255, 80));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Teachers");

        TeacherCount.setBackground(new java.awt.Color(0, 204, 204));
        TeacherCount.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        TeacherCount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TeacherCount.setText("0");

        javax.swing.GroupLayout pLayout = new javax.swing.GroupLayout(p);
        p.setLayout(pLayout);
        pLayout.setHorizontalGroup(
            pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
            .addComponent(TeacherCount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pLayout.setVerticalGroup(
            pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel16)
                .addGap(31, 31, 31)
                .addComponent(TeacherCount, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        Dashboard.add(p, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, 700, 170));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        Dashboard.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 870, 660));

        jTabbedPane1.addTab("tab1", Dashboard);

        StudentPortal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Search Student ");
        jPanel13.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, -1, -1));

        studentSearch.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        studentSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        studentSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentSearchActionPerformed(evt);
            }
        });
        studentSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                studentSearchKeyReleased(evt);
            }
        });
        jPanel13.add(studentSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 710, 40));

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Email", "ph#", "Password", "Security Question", "Security Answer"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        studentTable.setShowGrid(true);
        studentTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane2.setViewportView(studentTable);

        jPanel13.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 127, 780, 450));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        jPanel13.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 580));

        jTabbedPane2.addTab("List of students", jPanel13);

        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        studentSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentSectionActionPerformed(evt);
            }
        });
        jPanel14.add(studentSection, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, 260, 30));

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Section");
        jPanel14.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 30, -1, -1));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Student");
        jPanel14.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        studentName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentNameActionPerformed(evt);
            }
        });
        jPanel14.add(studentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 260, 30));

        course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseActionPerformed(evt);
            }
        });
        jPanel14.add(course, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, 260, 30));

        teacher.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        teacher.setForeground(new java.awt.Color(255, 255, 255));
        teacher.setText("Bilal Arif");
        jPanel14.add(teacher, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 108, 90, 30));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Course");
        jPanel14.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 30, -1, -1));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/teacher_1.png"))); // NOI18N
        jLabel33.setText("Teacher Name:");
        jPanel14.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, -1, -1));

        studentEnrollmentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "Course", "Teacher Name", "Section", "Days", "Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(studentEnrollmentTable);

        jPanel14.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 820, 400));

        jPanel15.setBackground(new java.awt.Color(0, 153, 153));
        jPanel15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel15MouseClicked(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/course_icon.png"))); // NOI18N
        jLabel34.setText("Enroll");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel34)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel14.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 100, 40));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        jPanel14.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 580));

        jTabbedPane2.addTab("Student Enrollment", jPanel14);

        StudentPortal.add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 870, 610));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        StudentPortal.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, -1, 660));

        jTabbedPane1.addTab("tab3", StudentPortal);

        UserPortal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        userAns.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        userAns.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        userAns.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userAnsActionPerformed(evt);
            }
        });
        UserPortal.add(userAns, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, 300, 30));

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("User Portal");
        UserPortal.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        UserName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UserName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        UserPortal.add(UserName, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 300, 30));

        userEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        userEmail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        userEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userEmailActionPerformed(evt);
            }
        });
        UserPortal.add(userEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 140, 300, 30));

        userNum.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        userNum.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        userNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userNumActionPerformed(evt);
            }
        });
        UserPortal.add(userNum, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 300, 30));

        userQue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "What was your high school name?", "Your First Teacher Name?", "What is your favorite color?", "What is your pet's name?", "What was your first car?", "What is your hobby?" }));
        userQue.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        UserPortal.add(userQue, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 300, 30));

        userRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Teacher" }));
        userRole.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        UserPortal.add(userRole, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 330, 290, 30));

        userPass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        userPass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        userPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userPassActionPerformed(evt);
            }
        });
        UserPortal.add(userPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 300, 30));

        userRegister.setBackground(new java.awt.Color(0, 153, 153));
        userRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        userRegister.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                userRegisterMouseClicked(evt);
            }
        });

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setText("Register");

        javax.swing.GroupLayout userRegisterLayout = new javax.swing.GroupLayout(userRegister);
        userRegister.setLayout(userRegisterLayout);
        userRegisterLayout.setHorizontalGroup(
            userRegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(userRegisterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel44, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addContainerGap())
        );
        userRegisterLayout.setVerticalGroup(
            userRegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(userRegisterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel44, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        UserPortal.add(userRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 250, 40));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Name");
        UserPortal.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Email");
        UserPortal.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, -1, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Password");
        UserPortal.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 210, -1, -1));

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("Phone Number");
        UserPortal.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));

        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("Security Question");
        UserPortal.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, -1, -1));

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setText("Role");
        UserPortal.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, -1, -1));

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("Answer");
        UserPortal.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, -1, -1));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        UserPortal.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, -1, 660));

        jTabbedPane1.addTab("tab5", UserPortal);

        A_Portal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel23.setBackground(new java.awt.Color(9, 38, 53));
        jPanel23.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel23MouseClicked(evt);
            }
        });

        jLabel68.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel68.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/editing.png"))); // NOI18N
        jLabel68.setText("Active");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel68, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel68, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel5.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 40));

        date.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        date.setForeground(new java.awt.Color(255, 255, 255));
        date.setText("Date");
        jPanel5.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        time.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        time.setForeground(new java.awt.Color(255, 255, 255));
        time.setText("Time");
        jPanel5.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 20, -1, -1));

        jLabel69.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 255, 255));
        jLabel69.setText("Section");
        jPanel5.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 80, -1, -1));

        A_PortalSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_PortalSectionActionPerformed(evt);
            }
        });
        jPanel5.add(A_PortalSection, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 110, 260, 30));

        A_portalCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_portalCourseActionPerformed(evt);
            }
        });
        jPanel5.add(A_portalCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 260, 30));

        jLabel70.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 255, 255));
        jLabel70.setText("Course");
        jPanel5.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, -1, -1));

        A_Teacher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_TeacherActionPerformed(evt);
            }
        });
        jPanel5.add(A_Teacher, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 260, 30));

        jLabel71.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(255, 255, 255));
        jLabel71.setText("Teacher");
        jPanel5.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jPanel24.setBackground(new java.awt.Color(0, 153, 153));
        jPanel24.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel24MouseClicked(evt);
            }
        });

        jLabel72.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(255, 255, 255));
        jLabel72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/list.png"))); // NOI18N
        jLabel72.setText("Submit");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel72, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel72, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel5.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 160, 100, 40));

        attendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        attendanceTable.setShowGrid(true);
        attendanceTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane9.setViewportView(attendanceTable);

        jPanel5.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 780, 360));

        jPanel26.setBackground(new java.awt.Color(0, 153, 153));
        jPanel26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel26MouseClicked(evt);
            }
        });

        jLabel78.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 255, 255));
        jLabel78.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/list.png"))); // NOI18N
        jLabel78.setText("Create");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel78, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel5.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 100, 40));

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel5.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane5.addTab("A-Portal", jPanel5);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel73.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(255, 255, 255));
        jLabel73.setText("Teacher");
        jPanel6.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        jLabel74.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(255, 255, 255));
        jLabel74.setText("Course");
        jPanel6.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, -1));

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 255, 255));
        jLabel75.setText("Section");
        jPanel6.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 40, -1, -1));

        A_PortalSection1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_PortalSection1ActionPerformed(evt);
            }
        });
        jPanel6.add(A_PortalSection1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 70, 260, 30));

        A_PortalCourse1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_PortalCourse1ActionPerformed(evt);
            }
        });
        jPanel6.add(A_PortalCourse1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 260, 30));

        A_Teacher1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_Teacher1ActionPerformed(evt);
            }
        });
        jPanel6.add(A_Teacher1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 260, 30));

        allAttendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        allAttendanceTable.setShowGrid(true);
        allAttendanceTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane10.setViewportView(allAttendanceTable);

        jPanel6.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 780, 390));

        jPanel25.setBackground(new java.awt.Color(0, 153, 153));
        jPanel25.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel25MouseClicked(evt);
            }
        });

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 255, 255));
        jLabel76.setText("Show");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel76)
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel76, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 100, 40));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel6.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane5.addTab("All Attendance", jPanel6);

        A_Portal.add(jTabbedPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 870, 630));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        A_Portal.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("tab6", A_Portal);

        Setting.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText("Profile");
        Setting.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        adminEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminEmail.setText(" Email");
        adminEmail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminEmailActionPerformed(evt);
            }
        });
        Setting.add(adminEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 140, 300, 30));

        adminName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminName.setText(" Name");
        adminName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Setting.add(adminName, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 300, 30));

        adminAns.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminAns.setText(" Answer");
        adminAns.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminAns.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminAnsActionPerformed(evt);
            }
        });
        Setting.add(adminAns, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 330, 300, 30));

        adminPh.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminPh.setText(" Ph#");
        adminPh.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminPh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminPhActionPerformed(evt);
            }
        });
        Setting.add(adminPh, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 300, 30));

        adminPass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminPass.setText(" Password");
        adminPass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminPassActionPerformed(evt);
            }
        });
        Setting.add(adminPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 300, 30));

        adminQue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "What was your high school name?", "Your First Teacher Name?", "What is your favorite color?", "What is your hobby?" }));
        adminQue.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Setting.add(adminQue, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 300, 30));

        jPanel20.setBackground(new java.awt.Color(9, 38, 53));
        jPanel20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel20MouseClicked(evt);
            }
        });

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/editing.png"))); // NOI18N
        jLabel53.setText("Active");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel53, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        Setting.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 130, 40));

        jPanel21.setBackground(new java.awt.Color(0, 153, 153));
        jPanel21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel21MouseClicked(evt);
            }
        });

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 255, 255));
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setText("Update");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel54, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel54, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        Setting.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 460, 250, 40));

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        Setting.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, -1, 660));

        jTabbedPane1.addTab("tab7", Setting);

        TeacherPortal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Search Teacher ");
        jPanel16.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, -1, -1));

        searchTeacher.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searchTeacher.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        searchTeacher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchTeacherActionPerformed(evt);
            }
        });
        searchTeacher.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTeacherKeyReleased(evt);
            }
        });
        jPanel16.add(searchTeacher, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 710, 40));

        teacherTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Email", "ph#", "Password", "Security Question", "Security Answer"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        teacherTable.setShowGrid(true);
        teacherTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane4.setViewportView(teacherTable);

        jPanel16.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 127, 760, 440));

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel16.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane3.addTab("List of Teacher", jPanel16);

        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        teacherSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherSectionActionPerformed(evt);
            }
        });
        jPanel17.add(teacherSection, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, 260, 30));

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Section");
        jPanel17.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 30, -1, -1));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Teacher");
        jPanel17.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        teacherName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherNameActionPerformed(evt);
            }
        });
        jPanel17.add(teacherName, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 260, 30));

        teacherCourse.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                teacherCourseItemStateChanged(evt);
            }
        });
        teacherCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherCourseActionPerformed(evt);
            }
        });
        jPanel17.add(teacherCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, 260, 30));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Course");
        jPanel17.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 30, -1, -1));

        jPanel18.setBackground(new java.awt.Color(0, 153, 153));
        jPanel18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel18MouseClicked(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/course_icon.png"))); // NOI18N
        jLabel41.setText("Assign");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel17.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 100, 40));

        workLoadTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Teacher", "Course", "Section", "Class Days", "Class Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(workLoadTable);

        jPanel17.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 820, 400));

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel17.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane3.addTab("WorkLoad Portal", jPanel17);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        studentStatusTable.setAutoCreateRowSorter(true);
        studentStatusTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        studentStatusTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        studentStatusTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null}
            },
            new String [] {
                "Student Name", "Course", "Section", "Day", "Time", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        studentStatusTable.setRowMargin(3);
        studentStatusTable.setShowGrid(true);
        jScrollPane7.setViewportView(studentStatusTable);
        if (studentStatusTable.getColumnModel().getColumnCount() > 0) {
            studentStatusTable.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(status_combo));
        }

        jPanel2.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 800, 400));

        jPanel19.setBackground(new java.awt.Color(0, 153, 153));
        jPanel19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel19MouseClicked(evt);
            }
        });

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 255, 255));
        jLabel60.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/upload.png"))); // NOI18N
        jLabel60.setText("Resolve");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel60, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel60, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, 130, 40));

        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("Teacher");
        jPanel2.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        advisorPortalSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                advisorPortalSearchActionPerformed(evt);
            }
        });
        jPanel2.add(advisorPortalSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 260, 30));

        jLabel58.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel2.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane3.addTab("Adviosr Portal", jPanel2);

        TeacherPortal.add(jTabbedPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 870, 610));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        TeacherPortal.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 6, -1, -1));

        jTabbedPane1.addTab("tab4", TeacherPortal);

        CoursePortal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel62.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(255, 255, 255));
        jLabel62.setText("Course Name :");
        jPanel3.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 100, -1));

        jLabel63.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 255, 255));
        jLabel63.setText("Course Code :");
        jPanel3.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 30, 100, -1));

        courseCode.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(courseCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 60, 320, 30));

        courseName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 320, 30));

        jLabel64.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/add.png"))); // NOI18N
        jLabel64.setText(" Add Section");
        jLabel64.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel64MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, -1, -1));

        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 255, 255));
        jLabel65.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/delete.png"))); // NOI18N
        jLabel65.setText(" Delete Section");
        jLabel65.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel65MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 110, -1, -1));

        CourseTable.setAutoCreateRowSorter(true);
        CourseTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        CourseTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        CourseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Section", "Day", "Time"
            }
        ));
        CourseTable.setToolTipText("");
        CourseTable.setShowGrid(true);
        CourseTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(CourseTable);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 660, 340));

        jPanel12.setBackground(new java.awt.Color(0, 153, 153));
        jPanel12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel12MouseClicked(evt);
            }
        });

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("Create Course");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(280, Short.MAX_VALUE)
                .addComponent(jLabel66)
                .addGap(262, 262, 262))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel66, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 520, 660, 40));

        jLabel61.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel3.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -5, -1, 640));

        jTabbedPane4.addTab("Course Enrollment", jPanel3);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 255, 255));
        jLabel67.setText("Search Course ");
        jPanel4.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, -1, -1));

        courseS.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        courseS.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        courseS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseSActionPerformed(evt);
            }
        });
        courseS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                courseSKeyReleased(evt);
            }
        });
        jPanel4.add(courseS, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 710, 40));

        coursetable.setAutoCreateRowSorter(true);
        coursetable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        coursetable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        coursetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course", "Course Code", "Section", "Days", "Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        coursetable.setRowMargin(3);
        coursetable.setShowGrid(true);
        coursetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                coursetableMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(coursetable);

        jPanel4.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 800, 430));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane4.addTab("List of Courses", jPanel4);

        CoursePortal.add(jTabbedPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 870, 620));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        CoursePortal.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 640));

        jTabbedPane1.addTab("tab2", CoursePortal);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, -40, 870, 670));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jLabel5MouseClicked

    private void studentSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentSearchActionPerformed

    private void studentSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentSectionActionPerformed
        // TODO add your handling code here:
        if (course.getSelectedItem() != null && studentSection.getSelectedItem() != null) {
            teacher.setText(University.TeacherWorkLoad(course.getSelectedItem().toString(), studentSection.getSelectedItem().toString()));
        }
    }//GEN-LAST:event_studentSectionActionPerformed

    private void studentNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentNameActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_studentNameActionPerformed

    private void courseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseActionPerformed
        // TODO add your handling code here:
        try {
            if (course.getSelectedItem() != null) {
                studentSection.removeAllItems();
                String selectedCourse = course.getSelectedItem().toString();
                String[] sections = University.SectionName(selectedCourse);
                if (sections.length > 0) {
                    for (String s : sections) {
                        studentSection.addItem(s);
                    }
                }
            }
        } catch (Exception e) {

        }
    }//GEN-LAST:event_courseActionPerformed

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void searchTeacherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchTeacherActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchTeacherActionPerformed

    private void teacherSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherSectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherSectionActionPerformed

    private void teacherNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherNameActionPerformed
        // TODO add your handling code 
    }//GEN-LAST:event_teacherNameActionPerformed

    private void teacherCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherCourseActionPerformed
        // TODO add your handling code here:
        try {
            if (teacherCourse.getSelectedItem() != null) {
                teacherSection.removeAllItems();
                String selectedCourse = teacherCourse.getSelectedItem().toString();
                String[] sections = University.SectionName(selectedCourse);
                if (sections.length > 0) {
                    for (String s : sections) {
                        teacherSection.addItem(s);
                    }
                }
            }
        } catch (Exception e) {

        }
    }//GEN-LAST:event_teacherCourseActionPerformed

    private void userAnsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userAnsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userAnsActionPerformed

    private void userEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userEmailActionPerformed

    private void userNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userNumActionPerformed

    private void userPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userPassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_userPassActionPerformed

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void adminEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminEmailActionPerformed

    private void adminPhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminPhActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminPhActionPerformed

    private void adminPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminPassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminPassActionPerformed

    private void adminAnsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminAnsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminAnsActionPerformed

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        int dis = JOptionPane.showConfirmDialog(null, "Do you want to loggged out");
        if (dis == 0) {
            this.setVisible(false);
            this.dispose();
            Login.obj = null;
            SignUp.obj = null;
            new Login().setVisible(true);
        }
    }//GEN-LAST:event_jLabel10MouseClicked

    private void studentSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studentSearchKeyReleased
        // TODO add your handling code here:
        ArrayList<User> obj = University.search(studentSearch.getText(), "Student");
        if (obj != null) {
            searchedStudents(obj, studentTable);
        } else {
            showStudentList("Sudent", studentTable);
        }
    }//GEN-LAST:event_studentSearchKeyReleased

    private void searchTeacherKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTeacherKeyReleased
        // TODO add your handling code here:
        ArrayList<User> obj = University.search(searchTeacher.getText(), "Teacher");
        if (obj != null) {
            searchedStudents(obj, teacherTable);
        } else {
            showStudentList("Teacher", teacherTable);
        }
    }//GEN-LAST:event_searchTeacherKeyReleased

    private void userRegisterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userRegisterMouseClicked
        // TODO add your handling code here:
        User u = new User();
        try {
            u.setName(UserName.getText().trim());
            u.setEmail(userEmail.getText().trim());
            u.setPassword(userPass.getText().trim());
            u.setSecurity_q(userQue.getSelectedItem().toString());
            u.setSecurity_a(userAns.getText().trim());
            u.setRole(userRole.getSelectedItem().toString());
            u.setPh_no(userNum.getText().trim());
            if (u.isValid()) {
                University.registerUser(u);
                if (u.getRole().equalsIgnoreCase("Student")) {
                    model = (DefaultTableModel) studentTable.getModel();
                    studentCount.setText((Integer.parseInt(studentCount.getText()) + 1) + "");
                    model.setRowCount(0);
                    showStudentList("Student", studentTable);
                    studentName.addItem(u.getName());
                } else {
                    model = (DefaultTableModel) teacherTable.getModel();
                    TeacherCount.setText((Integer.parseInt(TeacherCount.getText()) + 1) + "");
                    model.setRowCount(0);
                    showStudentList("Teacher", teacherTable);
                    teacherName.addItem(u.getName());
                    A_Teacher.addItem(u.getName());
                    A_Teacher1.addItem(u.getName());
                    advisorPortalSearch.addItem(u.getName());
                }
                UserName.setText("");
                userEmail.setText("");
                userPass.setText("");
                userAns.setText("");
                userNum.setText("");
                userRole.setSelectedIndex(0);
                userQue.setSelectedIndex(0);
            }
        } catch (IllegalArgumentException e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_userRegisterMouseClicked

    private void teacherCourseItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_teacherCourseItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_teacherCourseItemStateChanged

    private void jPanel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel18MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) workLoadTable.getModel();
            User u = University.UserSearchByName(teacherName.getSelectedItem().toString(), "Teacher");
            Course c = University.getCourseWithSections(teacherCourse.getSelectedItem().toString(), teacherSection.getSelectedItem().toString());
            String day = "";
            String time = "";
            boolean flag = false;
            for (int i = 0; i < 1; i++) {
                day = c.getSections().get(i).getClass_days();
                time = c.getSections().get(i).getClass_time_slot();
            }
            if (workLoadTable.getRowCount() > 0) {
                for (int i = 0; i < workLoadTable.getRowCount(); i++) {
                    for (Section s : c.getSections()) {
                        if (model.getValueAt(i, 1).toString().equalsIgnoreCase(c.getName())
                                && model.getValueAt(i, 2).toString().equalsIgnoreCase(s.getName())) {
                            if (model.getValueAt(i, 0).toString().equalsIgnoreCase(u.getName())) {
                                University.dialogeMsg("Already assigned");
                                flag = true;
                            } else {
                                University.dialogeMsg("Already assigned");
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (u != null && c != null && flag == false) {
                WorkLoad workLoad = new WorkLoad((Teacher) u, c);
                model.addRow(new Object[]{
                    u.getName(),
                    c.getName(),
                    teacherSection.getSelectedItem().toString(),
                    day,
                    time
                });
                if (University.WorkLoad(workLoad)) {
                    University.dialogeMsg("Assigned Sussessfully");
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }

    }//GEN-LAST:event_jPanel18MouseClicked

    private void status_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_status_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_status_comboActionPerformed

    private void jLabel64MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel64MouseClicked
        // TODO add your handling code here:
        model = (DefaultTableModel) CourseTable.getModel();
        model.addRow(new Object[1]);
    }//GEN-LAST:event_jLabel64MouseClicked

    private void jLabel65MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseClicked
        // TODO add your handling code here:
        model = (DefaultTableModel) CourseTable.getModel();
        int index = model.getRowCount() - 1;
        if (index >= 0) {
            model.removeRow(index);
        } else {
            JOptionPane.showMessageDialog(null, "section table already empty");
        }
    }//GEN-LAST:event_jLabel65MouseClicked

    private void jPanel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel12MouseClicked
        // TODO add your handling code here:
        try {
            boolean flag = false, flag1 = false;
            if (!courseName.getText().isEmpty() && !courseCode.getText().isEmpty()) {
                Course c = new Course();
                c.setName(courseName.getText());
                c.setC_code(courseCode.getText());
                model = (DefaultTableModel) CourseTable.getModel();
                ArrayList<Section> sections = new ArrayList<>();
                if (model.getRowCount() > 0) {
                    for (int i = 0; i < model.getRowCount(); i++) {
                        Section section = new Section();
                        section.setName(model.getValueAt(i, 0).toString());
                        section.setClass_days(model.getValueAt(i, 1).toString());
                        section.setClass_time_slot(model.getValueAt(i, 2).toString().trim());
                        sections.add(section);
                    }
                    c.setSections(sections);
                    DefaultTableModel model1 = (DefaultTableModel) coursetable.getModel();
                    for (int j = 0; j < model.getRowCount(); j++) {
                        for (int i = 0; i < model1.getRowCount(); i++) {
                            if (model1.getValueAt(i, 1).toString().equalsIgnoreCase(c.getC_code().trim()) && model1.getValueAt(i, 2).toString().equalsIgnoreCase(model.getValueAt(j, 0).toString().trim())) {
                                University.dialogeMsg("Created already");
                                flag1 = true;
                            }
                            if (model1.getValueAt(i, 1).toString().equalsIgnoreCase(c.getC_code())) {
                                flag = true;
                            }
                        }
                    }
                    if (flag1 == false) {
                        boolean isCreated = University.createCourse(c);
                        if (isCreated) {
                            University.dialogeMsg("Course created successfully");
                            if (flag == false) {
                                courseCount.setText((Integer.parseInt(courseCount.getText()) + 1) + "");
                                course.addItem(c.getName());
                                teacherCourse.addItem(c.getName());
                            }
                        } else {
                            University.dialogeMsg("Course creation failed. Course might already exist.");
                        }
                    }
                    courseCode.setText("");
                    courseName.setText("");
                    model.setRowCount(0);
                    showCourseList(coursetable);

                } else {
                    University.dialogeMsg("No sections created till now");
                }
            } else {
                University.dialogeMsg("Course name and code cannot be empty");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_jPanel12MouseClicked

    private void courseSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_courseSActionPerformed

    private void courseSKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courseSKeyReleased
        // TODO add your handling code here:
        ArrayList<Course> obj = University.search(courseS.getText());
        if (obj != null) {
            searchedCourses(obj, coursetable);
        } else {
            showCourseList(coursetable);
        }
    }//GEN-LAST:event_courseSKeyReleased

    private void A_PortalSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_PortalSectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_A_PortalSectionActionPerformed

    private void A_portalCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_portalCourseActionPerformed
        // TODO add your handling code here:
        try {
            if (A_portalCourse.getSelectedItem() != null && A_Teacher.getSelectedItem() != null) {
                A_PortalSection.removeAllItems();
                String selectedCourse = A_portalCourse.getSelectedItem().toString();
                String[] courses = University.teacherAssignedSections(selectedCourse, A_Teacher.getSelectedItem().toString());
                if (courses.length > 0) {
                    for (String s : courses) {
                        A_PortalSection.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_A_portalCourseActionPerformed

    private void A_TeacherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_TeacherActionPerformed
        // TODO add your handling code here
        try {
            if (A_Teacher.getSelectedItem() != null) {
                A_portalCourse.removeAllItems();
                A_PortalSection.removeAllItems();
                String selectedTeacher = A_Teacher.getSelectedItem().toString();
                String[] courses = University.teacherAssignedCourse(selectedTeacher);
                if (courses.length > 0) {
                    for (String s : courses) {
                        A_portalCourse.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_A_TeacherActionPerformed

    private void A_PortalSection1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_PortalSection1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_A_PortalSection1ActionPerformed

    private void A_PortalCourse1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_PortalCourse1ActionPerformed
        // TODO add your handling code here:
        try {
            if (A_PortalCourse1.getSelectedItem() != null && A_Teacher1.getSelectedItem() != null) {
                A_PortalSection1.removeAllItems();
                String selectedCourse = A_PortalCourse1.getSelectedItem().toString();
                String[] courses = University.teacherAssignedSections(selectedCourse, A_Teacher1.getSelectedItem().toString());
                if (courses.length > 0) {
                    for (String s : courses) {
                        A_PortalSection1.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_A_PortalCourse1ActionPerformed

    private void A_Teacher1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_Teacher1ActionPerformed
        // TODO add your handling code here:
        try {
            if (A_Teacher1.getSelectedItem() != null) {
                A_PortalCourse1.removeAllItems();
                A_PortalSection1.removeAllItems();
                String selectedTeacher = A_Teacher1.getSelectedItem().toString();
                String[] courses = University.teacherAssignedCourse(selectedTeacher);
                if (courses.length > 0) {
                    for (String s : courses) {
                        A_PortalCourse1.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_A_Teacher1ActionPerformed

    private void coursetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_coursetableMouseClicked
        // TODO add your handling code here:
        model = (DefaultTableModel) coursetable.getModel();
        int row = coursetable.getSelectedRow();
        if (row >= 0 && model.getRowCount() > 0) {
            String code = model.getValueAt(row, 1).toString();
            String name = model.getValueAt(row, 2).toString();
            int occurrenceCount = 0;
            int dis = JOptionPane.showConfirmDialog(null, "Do you want to delete this section of course ?");
            if (dis == JOptionPane.YES_OPTION) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    if (code.equalsIgnoreCase(model.getValueAt(i, 1).toString())) {
                        occurrenceCount++;
                    }
                }
                if (occurrenceCount > 1) {
                    model.removeRow(row);
                    studentSection.removeItem(name);
                    teacherSection.removeItem(name);
                    University.deleteSection(code, name);
                } else {
                    University.dialogeMsg("You cannot delete this course");
                }
            }
        }
    }//GEN-LAST:event_coursetableMouseClicked

    private void jPanel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel15MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) studentEnrollmentTable.getModel();
            User u = University.UserSearchByName(studentName.getSelectedItem().toString(), "Student");
            User u1 = University.UserSearchByName(teacher.getText(), "Teacher");
            Course c = University.getCourseWithSections(course.getSelectedItem().toString(), studentSection.getSelectedItem().toString());
            String day = "";
            String time = "";
            boolean flag = false;
            for (int i = 0; i < 1; i++) {
                day = c.getSections().get(i).getClass_days();
                time = c.getSections().get(i).getClass_time_slot();
            }
            if (studentEnrollmentTable.getRowCount() > 0) {
                for (int i = 0; i < studentEnrollmentTable.getRowCount(); i++) {
                    for (Section s : c.getSections()) {
                        if (model.getValueAt(i, 1).toString().equalsIgnoreCase(c.getName())
                                && model.getValueAt(i, 0).toString().equalsIgnoreCase(u.getName())) {
                            if (model.getValueAt(i, 3).toString().equalsIgnoreCase(s.getName())) {
                                University.dialogeMsg("Enrolled already");
                                flag = true;
                            } else {
                                University.dialogeMsg("Enrolled already");
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (u1 != null) {
                if (u != null && c != null && flag == false) {
                    Enrollment enroll = new Enrollment((Student) u, c, (Teacher) u1, "Pending");
                    model.addRow(new Object[]{
                        u.getName(),
                        c.getName(),
                        u1.getName(),
                        studentSection.getSelectedItem().toString(),
                        day,
                        time
                    });
                    if (University.Enrollment(enroll)) {
                        University.dialogeMsg("Enrolled Sussessfully");
                    }
                }
            } else {
                University.dialogeMsg("Cannot enroll into section as teacher is not assigned yet");
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel15MouseClicked

    private void advisorPortalSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_advisorPortalSearchActionPerformed
        // TODO add your handling code here:
        try {
            if (advisorPortalSearch.getSelectedItem() != null) {
                model = (DefaultTableModel) studentStatusTable.getModel();
                model.setRowCount(0);
                ArrayList<Enrollment> enroll = University.advisorValues(advisorPortalSearch.getSelectedItem().toString());
                if (enroll != null) {
                    for (Enrollment e : enroll) {
                        ArrayList<Section> sections = e.getCourse().getSections();
                        for (Section section : sections) {
                            Object[] col = new Object[6];
                            col[0] = e.getStd().getName();
                            col[1] = e.getCourse().getName();
                            col[2] = section.getName();
                            col[3] = section.getClass_days();
                            col[4] = section.getClass_time_slot();
                            col[5] = e.getStatus();
                            model.addRow(col);
                        }
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_advisorPortalSearchActionPerformed

    private void jPanel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel19MouseClicked
        // TODO add your handling code here:
        try {
            if (advisorPortalSearch.getSelectedItem() != null) {
                model = (DefaultTableModel) studentStatusTable.getModel();
                ArrayList<Enrollment> enroll = University.advisorValues(advisorPortalSearch.getSelectedItem().toString());
                int rowCount = model.getRowCount();
                int enrollCount = enroll.size();
                int minCount = Math.min(rowCount, enrollCount);
                for (int i = 0; i < minCount; i++) {
                    Enrollment e = enroll.get(i);
                    String status = model.getValueAt(i, 5).toString();
                    e.setStatus(status);
                }
                University.dialogeMsg("Resolved");
                for (int i = model.getRowCount() - 1; i >= 0; i--) {
                    if (model.getValueAt(i, 5).toString().equalsIgnoreCase("approved")) {
                        model.removeRow(i);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel19MouseClicked

    private void jPanel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel24MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) attendanceTable.getModel();
            if (model.getRowCount() > 0) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    Attendance e = new Attendance(model.getValueAt(i, 0).toString(), model.getValueAt(i, 1).toString(), A_portalCourse.getSelectedItem().toString());
                    University.markAttendance(e);
                }
                model.setRowCount(0);
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel24MouseClicked

    private void jPanel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel26MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) attendanceTable.getModel();
            model.setRowCount(0);
            String[] students = University.specifcEnrolledStudent(A_Teacher.getSelectedItem().toString(), A_portalCourse.getSelectedItem().toString(), A_PortalSection.getSelectedItem().toString());
            if (students != null) {
                for (String student : students) {
                    model.addRow(new Object[]{student, false});
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel26MouseClicked

    private void jPanel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel25MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) allAttendanceTable.getModel();
            model.setRowCount(0);
            String[] students = University.specifcEnrolledStudent(A_Teacher1.getSelectedItem().toString(), A_PortalCourse1.getSelectedItem().toString(), A_PortalSection1.getSelectedItem().toString());
            if (students != null) {
                for (String student : students) {
                    if (University.specificStudentAttendance(student) != null) {
                        model.addRow(new Object[]{student, University.specificStudentAttendance(student)});
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel25MouseClicked

    private void jPanel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel20MouseClicked
        // TODO add your handling code here:
        adminAns.setEditable(true);
        adminPass.setEditable(true);
        adminPh.setEditable(true);
    }//GEN-LAST:event_jPanel20MouseClicked

    private void jPanel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel21MouseClicked
        // TODO add your handling code here:
        User obj = new User();
        obj.setPassword(adminPass.getText().trim());
        obj.setPh_no(adminPh.getText().trim());
        obj.setEmail(adminEmail.getText().trim());
        obj.setName(adminName.getText().trim());
        obj.setSecurity_a(adminAns.getText().trim());
        obj.setSecurity_q(adminQue.getSelectedItem().toString().trim());
        if (obj.isValid()) {
            University.UpdateUser(obj, adminEmail.getText());
        }
    }//GEN-LAST:event_jPanel21MouseClicked

    private void jPanel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel23MouseClicked
        // TODO add your handling code here:
        A_Teacher.setEnabled(true);
        A_PortalSection.setEnabled(true);
        A_portalCourse.setEnabled(true);
    }//GEN-LAST:event_jPanel23MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel A_Portal;
    private javax.swing.JComboBox<String> A_PortalCourse1;
    private javax.swing.JComboBox<String> A_PortalSection;
    private javax.swing.JComboBox<String> A_PortalSection1;
    private javax.swing.JComboBox<String> A_Teacher;
    private javax.swing.JComboBox<String> A_Teacher1;
    private javax.swing.JComboBox<String> A_portalCourse;
    private javax.swing.JPanel CoursePortal;
    private javax.swing.JTable CourseTable;
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel Setting;
    private javax.swing.JPanel StudentPortal;
    private javax.swing.JLabel TeacherCount;
    private javax.swing.JPanel TeacherPortal;
    private javax.swing.JTextField UserName;
    private javax.swing.JPanel UserPortal;
    private javax.swing.JTextField adminAns;
    private javax.swing.JTextField adminEmail;
    private javax.swing.JTextField adminName;
    private javax.swing.JTextField adminPass;
    private javax.swing.JTextField adminPh;
    private javax.swing.JComboBox<String> adminQue;
    private javax.swing.JComboBox<String> advisorPortalSearch;
    private javax.swing.JTable allAttendanceTable;
    private javax.swing.JTable attendanceTable;
    private javax.swing.JPanel c;
    private javax.swing.JComboBox<String> course;
    private javax.swing.JTextField courseCode;
    private javax.swing.JLabel courseCount;
    private javax.swing.JTextField courseName;
    private javax.swing.JTextField courseS;
    private javax.swing.JTable coursetable;
    private javax.swing.JLabel date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JPanel p;
    private javax.swing.JPanel s;
    private javax.swing.JTextField searchTeacher;
    private javax.swing.JComboBox<String> status_combo;
    private javax.swing.JLabel studentCount;
    private javax.swing.JTable studentEnrollmentTable;
    private javax.swing.JComboBox<String> studentName;
    private javax.swing.JTextField studentSearch;
    private javax.swing.JComboBox<String> studentSection;
    private javax.swing.JTable studentStatusTable;
    private javax.swing.JTable studentTable;
    private javax.swing.JLabel teacher;
    private javax.swing.JComboBox<String> teacherCourse;
    private javax.swing.JComboBox<String> teacherName;
    private javax.swing.JComboBox<String> teacherSection;
    private javax.swing.JTable teacherTable;
    private javax.swing.JLabel time;
    private javax.swing.JTextField userAns;
    private javax.swing.JTextField userEmail;
    private javax.swing.JTextField userNum;
    private javax.swing.JTextField userPass;
    private javax.swing.JComboBox<String> userQue;
    private javax.swing.JPanel userRegister;
    private javax.swing.JComboBox<String> userRole;
    private javax.swing.JTable workLoadTable;
    // End of variables declaration//GEN-END:variables
}
