package attendancemanagementsystem;

public class Attendance {

    private String name;
    private String attendance;
    private String course;

    public Attendance() {
    }

    public Attendance(String name, String attendance, String course) {
        this.name = name;
        this.attendance = attendance;
        this.course=course;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }

}
