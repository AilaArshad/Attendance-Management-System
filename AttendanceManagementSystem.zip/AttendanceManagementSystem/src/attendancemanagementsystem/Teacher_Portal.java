/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package attendancemanagementsystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aila Arshad
 */
public class Teacher_Portal extends javax.swing.JFrame {

    /**
     * Creates new form Teacher_Portal
     */
    DefaultTableModel model;
    static String value;

    public Teacher_Portal() {
        initComponents();
        this.setLocationRelativeTo(null);
        time();
        date();
        defaultTextSetter();
        if (Login.obj != null) {
            profileSetting(Login.obj);
            value = Login.obj.getName();
        } else if (SignUp.obj != null) {
            profileSetting(SignUp.obj);
            value = SignUp.obj.getName();
        }
        courseValue.setText(University.countUniqueCourses(value) + "");
        studentValue.setText(University.countUniqueStudents(value) + "");
        advisorvalues();
        enrolledCourses();
        comboSetting();
    }

    void advisorvalues() {
        try {
            model = (DefaultTableModel) student_list1.getModel();
            ArrayList<Enrollment> enroll = University.advisorValues(value);
            if (enroll != null) {
                for (Enrollment e : enroll) {
                    ArrayList<Section> sections = e.getCourse().getSections();
                    for (Section section : sections) {
                        Object[] col = new Object[6];
                        col[0] = e.getStd().getName();
                        col[1] = e.getCourse().getName();
                        col[2] = section.getName();
                        col[3] = section.getClass_days();
                        col[4] = section.getClass_time_slot();
                        col[5] = e.getStatus();
                        model.addRow(col);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }

    void profileSetting(User obj) {
        T_name.setText(obj.getName());
        T_password.setText(obj.getPassword());
        T_email.setText(obj.getEmail());
        T_ques.setSelectedItem(obj.getSecurity_q());
        T_ans.setText(obj.getSecurity_a());
        T_ph.setText(obj.getPh_no());
        T_role.setSelectedItem(obj.getRole());
    }

    void defaultTextSetter() {
        T_name.setEditable(false);
        T_password.setEditable(false);
        T_email.setEditable(false);
        T_ques.setEditable(false);
        T_ans.setEditable(false);
        T_ph.setEditable(false);
        T_role.setEditable(false);
        course.setEnabled(false);
        section.setEditable(false);
    }

    void searchedEnrollments(ArrayList<Enrollment> list) {
        try {
            model = (DefaultTableModel) student_list1.getModel();
            if (list != null) {
                model.setRowCount(0);
                for (Enrollment e : list) {
                    ArrayList<Section> sections = e.getCourse().getSections();
                    for (Section section : sections) {
                        Object[] col = new Object[6];
                        col[0] = e.getStd().getName();
                        col[1] = e.getCourse().getName();
                        col[2] = section.getName();
                        col[3] = section.getClass_days();
                        col[4] = section.getClass_time_slot();
                        col[5] = e.getStatus();
                        model.addRow(col);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }

    void enrolledCourses() {
        try {
            model = (DefaultTableModel) enrolled_courses1.getModel();
            ArrayList<WorkLoad> work = University.allAssignedCourses(value);
            if (work != null) {
                model.setRowCount(0);
                for (WorkLoad e : work) {
                    ArrayList<Section> sections = e.getCourse().getSections();
                    for (Section section : sections) {
                        Object[] col = new Object[4];
                        col[0] = e.getCourse().getName();
                        col[1] = section.getName();
                        col[2] = section.getClass_days();
                        col[3] = section.getClass_time_slot();
                        model.addRow(col);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }

    void comboSetting() {
        try {
            if (value != null) {
                course.removeAllItems();
                section.removeAllItems();
                String selectedTeacher = value;
                String[] courses = University.teacherAssignedCourse(selectedTeacher);
                if (courses.length > 0) {
                    for (String s : courses) {
                        course.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }

    public void date() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM-dd");
        String dd = sdf.format(d);
        date.setText(dd);

    }
    Timer t;
    SimpleDateFormat sdf;

    public void time() {

        t = new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date dt = new Date();
                sdf = new SimpleDateFormat("hh:mm:ss a");
                String s = sdf.format(dt);
                time.setText(s);
            }
        });
        t.start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        status_combo = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Dashboard = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        studentValue = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        courseValue = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Advisor_Portal = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        studentSearch = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        student_list1 = new javax.swing.JTable();
        jPanel18 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        enrolled_courses1 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        A_Portal = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        course = new javax.swing.JComboBox<>();
        jLabel50 = new javax.swing.JLabel();
        section = new javax.swing.JComboBox<>();
        date = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        attendanceTable = new javax.swing.JTable();
        jPanel20 = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        Setting = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        T_email = new javax.swing.JTextField();
        T_name = new javax.swing.JTextField();
        T_ans = new javax.swing.JTextField();
        T_ph = new javax.swing.JTextField();
        T_password = new javax.swing.JTextField();
        T_ques = new javax.swing.JComboBox<>();
        ActiveProfile = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        T_role = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();

        status_combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Approved", "Cancelled" }));
        status_combo.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        status_combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                status_comboActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(9, 38, 53));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/employee (2).png"))); // NOI18N
        jLabel1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Teacher");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/home.png"))); // NOI18N
        jLabel3.setText(" Dashboard");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/teacher.png"))); // NOI18N
        jLabel6.setText(" Advisor Portal");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/attendance.png"))); // NOI18N
        jLabel8.setText(" A-Portal");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/setting.png"))); // NOI18N
        jLabel9.setText(" Setting");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/logout.png"))); // NOI18N
        jLabel10.setText(" Log Out");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(41, 41, 41)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(109, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 280, 630));

        Dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(255, 255, 255, 80));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Students");

        studentValue.setBackground(new java.awt.Color(0, 204, 204));
        studentValue.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        studentValue.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        studentValue.setText("0");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(studentValue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel11)
                .addGap(32, 32, 32)
                .addComponent(studentValue, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        Dashboard.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 330, 190));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255, 80));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel13.setText("Courses");

        courseValue.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        courseValue.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        courseValue.setText("0");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(courseValue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel13)
                .addGap(30, 30, 30)
                .addComponent(courseValue, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        Dashboard.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 60, 330, 190));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        Dashboard.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("tab1", Dashboard);

        Advisor_Portal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Search Student ");
        jPanel2.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, -1, -1));

        studentSearch.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        studentSearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        studentSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentSearchActionPerformed(evt);
            }
        });
        studentSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                studentSearchKeyReleased(evt);
            }
        });
        jPanel2.add(studentSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 710, 40));

        student_list1.setAutoCreateRowSorter(true);
        student_list1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        student_list1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        student_list1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "Course", "Section", "Days", "Time", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        student_list1.setRowMargin(3);
        student_list1.setShowGrid(true);
        jScrollPane6.setViewportView(student_list1);
        if (student_list1.getColumnModel().getColumnCount() > 0) {
            student_list1.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(status_combo));
        }

        jPanel2.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 780, 360));

        jPanel18.setBackground(new java.awt.Color(0, 153, 153));
        jPanel18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel18MouseClicked(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/upload.png"))); // NOI18N
        jLabel41.setText("Resolve");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 130, 40));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane2.addTab("Advisor Portal", jPanel2);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        enrolled_courses1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course", "Section", "Class Days", "Class Timing"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        enrolled_courses1.setToolTipText("Assigned Courses Load ");
        enrolled_courses1.setEnabled(false);
        enrolled_courses1.setShowGrid(true);
        enrolled_courses1.setSurrendersFocusOnKeystroke(true);
        jScrollPane7.setViewportView(enrolled_courses1);

        jPanel6.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 780, 500));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        jPanel6.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane2.addTab("Course Load", jPanel6);

        Advisor_Portal.add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 860, 630));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        Advisor_Portal.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("tab2", Advisor_Portal);

        A_Portal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("Course");
        A_Portal.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 80, -1, -1));

        course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseActionPerformed(evt);
            }
        });
        A_Portal.add(course, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 260, 30));

        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("Section");
        A_Portal.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 80, -1, -1));

        section.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sectionActionPerformed(evt);
            }
        });
        A_Portal.add(section, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, 260, 30));

        date.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        date.setForeground(new java.awt.Color(255, 255, 255));
        date.setText("Date");
        A_Portal.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        time.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        time.setForeground(new java.awt.Color(255, 255, 255));
        time.setText("Time");
        A_Portal.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 20, -1, -1));

        attendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        attendanceTable.setShowGrid(true);
        attendanceTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane8.setViewportView(attendanceTable);

        A_Portal.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 207, 760, 390));

        jPanel20.setBackground(new java.awt.Color(9, 38, 53));
        jPanel20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel20MouseClicked(evt);
            }
        });

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/editing.png"))); // NOI18N
        jLabel53.setText("Active");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel53, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        A_Portal.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 140, 40));

        jPanel15.setBackground(new java.awt.Color(0, 153, 153));
        jPanel15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel15MouseClicked(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/list.png"))); // NOI18N
        jLabel34.setText("Create");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel34)
                .addContainerGap(9, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        A_Portal.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 100, 40));

        jPanel24.setBackground(new java.awt.Color(0, 153, 153));
        jPanel24.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel24MouseClicked(evt);
            }
        });

        jLabel72.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(255, 255, 255));
        jLabel72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/list.png"))); // NOI18N
        jLabel72.setText("Submit");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel72, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel72, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addContainerGap())
        );

        A_Portal.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 150, 100, 40));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back2 (4).jpg"))); // NOI18N
        A_Portal.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("tab3", A_Portal);

        Setting.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText("Profile");
        Setting.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        T_email.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        T_email.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        T_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_emailActionPerformed(evt);
            }
        });
        Setting.add(T_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 140, 300, 30));

        T_name.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        T_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Setting.add(T_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 300, 30));

        T_ans.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        T_ans.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        T_ans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_ansActionPerformed(evt);
            }
        });
        Setting.add(T_ans, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, 300, 30));

        T_ph.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        T_ph.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        T_ph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_phActionPerformed(evt);
            }
        });
        Setting.add(T_ph, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 300, 30));

        T_password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        T_password.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        T_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_passwordActionPerformed(evt);
            }
        });
        Setting.add(T_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 300, 30));

        T_ques.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "What was your high school name?", "Your First Teacher Name?", "What is your favorite color?", "What is your pet's name?", "What was your first car?", "What is your hobby?" }));
        T_ques.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Setting.add(T_ques, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 300, 30));

        ActiveProfile.setBackground(new java.awt.Color(9, 38, 53));
        ActiveProfile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ActiveProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ActiveProfileMouseClicked(evt);
            }
        });

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 255, 255));
        jLabel54.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/editing.png"))); // NOI18N
        jLabel54.setText("Active");

        javax.swing.GroupLayout ActiveProfileLayout = new javax.swing.GroupLayout(ActiveProfile);
        ActiveProfile.setLayout(ActiveProfileLayout);
        ActiveProfileLayout.setHorizontalGroup(
            ActiveProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ActiveProfileLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        ActiveProfileLayout.setVerticalGroup(
            ActiveProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel54, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        Setting.add(ActiveProfile, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 40, 130, 40));

        jPanel22.setBackground(new java.awt.Color(0, 153, 153));
        jPanel22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel22MouseClicked(evt);
            }
        });

        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel55.setText("Update");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel55, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel55, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        Setting.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 250, 40));

        T_role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Teacher" }));
        T_role.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Setting.add(T_role, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 340, 300, 30));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Name");
        Setting.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Email");
        Setting.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, -1, -1));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Phone Number");
        Setting.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, -1, -1));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Password");
        Setting.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 210, -1, -1));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Security Question");
        Setting.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, -1, -1));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Role");
        Setting.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, -1, -1));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Answer");
        Setting.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, -1, -1));

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/attendancemanagementsystem/icons/back3 (2).jpg"))); // NOI18N
        Setting.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("tab4", Setting);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, -40, 860, 670));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        int dis = JOptionPane.showConfirmDialog(null, "Do you want to loggged out");
        if (dis == 0) {
            this.setVisible(false);
            this.dispose();
            Login.obj = null;
            SignUp.obj = null;
            new Login().setVisible(true);
        }
    }//GEN-LAST:event_jLabel10MouseClicked

    private void status_comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_status_comboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_status_comboActionPerformed

    private void courseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseActionPerformed
        // TODO add your handling code here:
        try {
            if (course.getSelectedItem() != null && value != null) {
                section.removeAllItems();
                String selectedCourse = course.getSelectedItem().toString();
                String[] courses = University.teacherAssignedSections(selectedCourse, value);
                if (courses.length > 0) {
                    for (String s : courses) {
                        section.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_courseActionPerformed

    private void sectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sectionActionPerformed

    private void T_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_emailActionPerformed

    private void T_ansActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_ansActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_ansActionPerformed

    private void T_phActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_phActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_phActionPerformed

    private void T_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_passwordActionPerformed

    private void ActiveProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ActiveProfileMouseClicked
        // TODO add your handling code here:
        T_password.setEditable(true);
        T_ques.setEditable(true);
        T_ans.setEditable(true);
        T_ph.setEditable(true);
        T_role.setEditable(true);
    }//GEN-LAST:event_ActiveProfileMouseClicked

    private void jPanel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel22MouseClicked
        // TODO add your handling code here:
        User obj = new User();
        obj.setPassword(T_password.getText().trim());
        obj.setPh_no(T_ph.getText().trim());
        obj.setEmail(T_email.getText().trim());
        obj.setName(T_name.getText().trim());
        obj.setRole(T_role.getSelectedItem().toString().trim());
        obj.setSecurity_a(T_ans.getText().trim());
        obj.setSecurity_q(T_ques.getSelectedItem().toString().trim());
        if (obj.isValid()) {
            University.UpdateUser(obj, T_email.getText());
        }
    }//GEN-LAST:event_jPanel22MouseClicked

    private void studentSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentSearchActionPerformed

    private void jPanel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel18MouseClicked
        // TODO add your handling code here:
        try {
            if (value != null) {
                model = (DefaultTableModel) student_list1.getModel();
                ArrayList<Enrollment> enroll = University.advisorValues(value);
                int rowCount = model.getRowCount();
                int enrollCount = enroll.size();
                int minCount = Math.min(rowCount, enrollCount);
                for (int i = 0; i < minCount; i++) {
                    Enrollment e = enroll.get(i);
                    String status = model.getValueAt(i, 5).toString();
                    e.setStatus(status);
                }
                University.dialogeMsg("Resolved");
                for (int i = model.getRowCount() - 1; i >= 0; i--) {
                    if (model.getValueAt(i, 5).toString().equalsIgnoreCase("approved")) {
                        model.removeRow(i);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel18MouseClicked

    private void studentSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studentSearchKeyReleased
        // TODO add your handling code here:
        ArrayList<Enrollment> obj = University.searchEnrolledStudent(studentSearch.getText());
        if (obj != null) {
            searchedEnrollments(obj);
        } else {
            advisorvalues();
        }
    }//GEN-LAST:event_studentSearchKeyReleased

    private void jPanel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel24MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) attendanceTable.getModel();
            if (model.getRowCount() > 0) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    Attendance e = new Attendance(model.getValueAt(i, 0).toString(), model.getValueAt(i, 1).toString(), course.getSelectedItem().toString());
                    University.markAttendance(e);
                }
                model.setRowCount(0);
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel24MouseClicked

    private void jPanel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel15MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) attendanceTable.getModel();
            model.setRowCount(0);
            String[] students = University.specifcEnrolledStudent(value, course.getSelectedItem().toString(), section.getSelectedItem().toString());
            if (students != null) {
                for (String student : students) {
                    model.addRow(new Object[]{student, false});
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel15MouseClicked

    private void jPanel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel20MouseClicked
        // TODO add your handling code here:
        course.setEnabled(true);
        section.setEnabled(true);
    }//GEN-LAST:event_jPanel20MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Teacher_Portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Teacher_Portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Teacher_Portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Teacher_Portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Teacher_Portal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel A_Portal;
    private javax.swing.JPanel ActiveProfile;
    private javax.swing.JPanel Advisor_Portal;
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel Setting;
    private javax.swing.JTextField T_ans;
    private javax.swing.JTextField T_email;
    private javax.swing.JTextField T_name;
    private javax.swing.JTextField T_password;
    private javax.swing.JTextField T_ph;
    private javax.swing.JComboBox<String> T_ques;
    private javax.swing.JComboBox<String> T_role;
    private javax.swing.JTable attendanceTable;
    private javax.swing.JComboBox<String> course;
    private javax.swing.JLabel courseValue;
    private javax.swing.JLabel date;
    private javax.swing.JTable enrolled_courses1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JComboBox<String> section;
    private javax.swing.JComboBox<String> status_combo;
    private javax.swing.JTextField studentSearch;
    private javax.swing.JLabel studentValue;
    private javax.swing.JTable student_list1;
    private javax.swing.JLabel time;
    // End of variables declaration//GEN-END:variables
}
