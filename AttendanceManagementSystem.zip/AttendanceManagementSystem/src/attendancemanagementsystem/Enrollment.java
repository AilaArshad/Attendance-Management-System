package attendancemanagementsystem;

public class Enrollment {

    private Student std;
    private Course course;
    private Teacher tea;
    private String status;

    public Enrollment() {

    }

    public Enrollment(Student std, Course course, Teacher tea, String status) {
        this.std = std;
        this.course = course;
        this.tea = tea;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Teacher getTea() {
        return tea;
    }

    public void setTea(Teacher tea) {
        this.tea = tea;
    }

    public Student getStd() {
        return std;
    }

    public void setStd(Student std) {
        this.std = std;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

}
